# Oxide Drop — шаблон Telegram Mini App

В шаблоне уже есть:
- баланс монет;
- 4 кейса;
- открытие кейса и случайная награда;
- задания и бонусы;
- промокоды CRASH / START / OXYGEN;
- профиль;
- подключение Telegram WebApp API;
- сохранение демо-баланса в localStorage.

## Как запустить с телефона

1. Распакуй архив.
2. Создай репозиторий на GitHub и загрузи `index.html`.
3. В Vercel нажми Add New → Project → Import Git Repository.
4. Разверни проект.
5. Полученный HTTPS-адрес можно использовать как URL Mini App.

## Подключение к Telegram

В @BotFather создай бота и настрой кнопку Menu Button / Web App на URL Vercel.

Важно: этот шаблон — демонстрационная версия. Баланс хранится в браузере и не является защищённым. Для настоящего проекта нужны серверная база данных, серверная проверка Telegram initData и серверная логика начислений/выводов.

## Следующий этап

Подключить Supabase:
users, balances, cases, inventory, tasks, promo_codes, promo_uses.

Никогда не храни секретные токены и права администратора только в JavaScript Mini App.
